Folder for third party libraries
