[
    {
      title: 'Frozen',
      movie_id: '456789',
      movie_link: 'http://www.google.com',
      movie_poster: 'http://placekitten.com/g/200/300',
      genre: ['Comedy'],
      rating: 'PG',
      runtime: '1hr 32min',
      release_type: 'Nationwide',
      release_date: '2/12/2014',
      releases: ['1391472000']
    },
    {
      title: 'Frozen2',
      movie_id: '098657',
      movie_link: 'http://www.yahoo.com',
      movie_poster: 'http://placekitten.com/g/200/200',
      genre: ['Action/Adventure'],
      rating: 'R',
      runtime: '1hr 32min',
      release_type: 'Nationwide',
      release_date: '2/13/2014',
      releases: ['1391472000']
    },
    {
      title: 'Frozen3',
      movie_id: '243234',
      movie_link: 'http://www.hotmail.com',
      movie_poster: 'http://placekitten.com/g/400/200',
      genre: ['Animation'],
      rating: 'NR',
      runtime: '1hr 32min',
      release_type: 'Nationwide',
      release_date: '2/14/2014',
      releases: ['1391472000']
    }]