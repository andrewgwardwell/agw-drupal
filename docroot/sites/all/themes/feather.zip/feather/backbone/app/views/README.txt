Folder for custom Backbone views
