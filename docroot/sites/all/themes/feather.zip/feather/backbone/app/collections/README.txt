Folder for custom Backbone collections
