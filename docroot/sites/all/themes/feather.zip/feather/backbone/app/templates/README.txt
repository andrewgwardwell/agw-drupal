Folder for templates
